// TIBCO Rendezvous API Java Development
// File: TimerRv3.java
// TIBCO Education Services
// Copyright 2005 - TIBCO Software Inc.
// ALL RIGHTS RESERVED

import com.tibco.tibrv.*;

class TimerRv3 {
   static TibrvTimer timer1;
   static TibrvQueue queue;
   double seconds= 2.0;

   public static void main(String[] args) {
       new TimerRv3();
   }

   TimerRv3() {
    try {
      Tibrv.open();
      setTimer(seconds);
      Tibrv.close();
    }
    catch(Exception e) {
       System.err.println(e);
       System.exit(-1);
    }
   }

   void setTimer(double seconds) throws TibrvException, InterruptedException {
      queue= Tibrv.defaultQueue();
      timer1= new TibrvTimer(queue, new TimerCallback(this), seconds, null);
      TibrvDispatcher d1= new TibrvDispatcher(queue);
      TibrvDispatcher d2= new TibrvDispatcher(queue);
      TibrvDispatcher d3= new TibrvDispatcher(queue);
      d1.join();
      d2.join();
      d3.join();
   }
}


class TimerCallback implements TibrvTimerCallback {
   TimerRv3 t;
   TimerCallback(TimerRv3 trv) { t= trv; }

   int count;
   public void onTimer(TibrvTimer timerEvent) {
      System.out.println(++count + " Timer Expired.");
      try { Thread.sleep(10000); }
      catch(InterruptedException ix) {}
    }
}
