// TIBCO Rendezvous API Java Development
// File: Priority2.java
// TIBCO Education Services
// Copyright 2005 - TIBCO Software Inc.
// ALL RIGHTS RESERVED

import com.tibco.tibrv.*;

public class Priority2 implements TibrvMsgCallback
{
    String subject1 = "1";
    String subject2 = "2";
    String subject3 = "3";

    public void execute()
    {
        try
        {
            // open Tibrv environment
            Tibrv.open();

            // get process transport
            TibrvTransport transport = Tibrv.processTransport();

            // create 3 queues
            TibrvQueue queue1 = new TibrvQueue();
            TibrvQueue queue2 = new TibrvQueue();
            TibrvQueue queue3 = new TibrvQueue();

            // set priorities
            queue1.setPriority(1);
            queue2.setPriority(2);
            queue3.setPriority(2);

            // Create queue group and add queues
            TibrvQueueGroup group = new TibrvQueueGroup();
            group.add(queue1);
            group.add(queue2);
            group.add(queue3);

            queue1.setLimitPolicy(TibrvQueue.DISCARD_FIRST, 3, 2);
            queue2.setLimitPolicy(TibrvQueue.DISCARD_FIRST, 3, 2);
            queue3.setLimitPolicy(TibrvQueue.DISCARD_FIRST, 3, 2);

            // Create listeners
            new TibrvListener(queue1,this,transport,subject1,null);
            new TibrvListener(queue2,this,transport,subject2,null);
            new TibrvListener(queue3,this,transport,subject3,null);

            // Prepare the message
            TibrvMsg msg = new TibrvMsg();

            // Send 10 messages on subject1
            msg.setSendSubject(subject1);
            for (int i=0; i<10; i++)
            {
                msg.update("field","value-1-"+(i+1));
                transport.send(msg);
            }

            // Send 10 messages on subject2
            msg.setSendSubject(subject2);
            for (int i=0; i<10; i++)
            {
                msg.update("field","value-2-"+(i+1));
                transport.send(msg);
            }

            // Send 10 messages on subject3
            msg.setSendSubject(subject3);
            for (int i=0; i<10; i++)
            {
                msg.update("field","value-3-"+(i+1));
                transport.send(msg);
            }

            // Create dispatcher thread with timeout 1 second
            TibrvDispatcher dispatcher =
                    new TibrvDispatcher("dispatcher",group,1);

            // Wait until dispatcher processes all messages
            // and exits after 1 second timeout
            try
            {
                dispatcher.join();
            }
            catch(InterruptedException e)
            {
            }

            // Close Tibrv
            Tibrv.close();
        }
        catch (TibrvException rve)
        {
            // this program does not use the network
            // and supposedly should never fail.
            rve.printStackTrace();
            System.exit(0);
        }

    }

    // Message callback
    public void onMsg(TibrvListener listener, TibrvMsg msg)
    {
        System.out.println("Received message on subject "+
                           msg.getSendSubject()+": "+msg);
        try {
          Thread.sleep(2500);
        }
        catch (InterruptedException ix) {}
    }

    public static void main(String args[])
    {
        new Priority2().execute();
    }

}
