// TIBCO Rendezvous API Java Development
// File: TimerRv2.java
// TIBCO Education Services
// Copyright 2005 - TIBCO Software Inc.
// ALL RIGHTS RESERVED

import com.tibco.tibrv.*;

class TimerRv2 {
   static TibrvTimer timer1;
   static TibrvQueue[] queue;
   double seconds= 2.0;

   public static void main(String[] args) {
       new TimerRv2();
   }

   TimerRv2() {
    try {
      Tibrv.open();
      setTimer(seconds);
      Tibrv.close();
    }
    catch(Exception e) {
       System.err.println(e);
       System.exit(-1);
    }
   }

   void setTimer(double seconds) throws TibrvException, InterruptedException {
      queue= new TibrvQueue[] { new TibrvQueue(), new TibrvQueue(), new TibrvQueue()};
      TibrvQueueGroup qGroup= new TibrvQueueGroup();
      for  (int i= 0;  i < queue.length;  ++i) {
         new TibrvTimer(queue[i], new TimerCallback(this), seconds+i, null);
         qGroup.add(queue[i]);
      }
      new TibrvDispatcher(qGroup).join();
   }
}


class TimerCallback implements TibrvTimerCallback {
   TimerRv2 t;
   TimerCallback(TimerRv2 trv) { t= trv; }

   int count;
   public void onTimer(TibrvTimer timerEvent) {
      System.out.println(++count + " Timer " + timerEvent.getInterval() + " Expired.");
      try { Thread.sleep(count*1000); }
      catch(InterruptedException ix) {}
   }
}
