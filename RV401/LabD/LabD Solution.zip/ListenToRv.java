// TIBCO Rendezvous API Java Development
// File: ListenToRV.java
// TIBCO Education Services
// Copyright 2005- TIBCO Software Inc.
// ALL RIGHTS RESERVED

import com.tibco.tibrv.*;

class ListenToRv implements TibrvMsgCallback {
   ListenToRv(String[] args) throws TibrvException {
      if  (args.length < 1) {
         System.out.println("Usage: ListenToRv SUBJECT ...");
         System.exit(1);
      }

      Tibrv.open(Tibrv.IMPL_NATIVE);
      TibrvTransport transport= new TibrvRvdTransport();
      for  (int i= 0; i < args.length;  ++i) {
         new TibrvListener(Tibrv.defaultQueue(),
                           this,
                           transport,
                           args[i],
                           null);
      }

      for (;;)
         try {
            Tibrv.defaultQueue().dispatch();
         }
         catch(InterruptedException ix) {}
   }

   public static void main(String[] args) throws TibrvException {
      new ListenToRv(args);
   }

   public void onMsg(TibrvListener l, TibrvMsg m) {
      System.out.println("Message received with subject: " + m.getSendSubject());
      System.out.println("Msg: " + m);
   }
}