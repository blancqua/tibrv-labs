/*
 * TIBCO Rendezvous API Java Development
 * File : sdlisten.java
 * TIBCO Education Services
 * Copyright 2005 - TIBCO Software Inc.
 * ALL RIGHTS RESERVED
 *
 */

import java.util.*;
import com.tibco.tibrv.*;

public class SdListen implements TibrvMsgCallback
{
    String daemon  = "ssl:localhost:7500";
    String username= null;
    String password= null;

    public SdListen(String args[])
    {
        // parse arguments
        int i = get_InitParams(args);

        // we must have at least one subject
        if ((i >= args.length) || (username == null) || (password == null))
            usage();

        // open Tibrv in native implementation
        try
        {
            Tibrv.open(Tibrv.IMPL_NATIVE);
        }
        catch (TibrvException e)
        {
            System.err.println("Failed to open Tibrv in native implementation:");
            e.printStackTrace();
            System.exit(0);
        }

        // Create RVD transport
        TibrvRvdTransport transport = null;
        try
        {
		TibrvSdContext.setDaemonCert(TibrvSdContext.TIBRV_SECURE_DAEMON_ANY_NAME, TibrvSdContext.TIBRV_SECURE_DAEMON_ANY_CERT);
		TibrvSdContext.setUserNameWithPassword(username, password);

		transport = new TibrvRvdTransport(null, null, daemon);
        }
        catch (TibrvException e)
        {
            System.err.println("Failed to create TibrvRvdTransport:");
            e.printStackTrace();
            System.exit(0);
        }

        // Create listeners for specified subjects
        while (i < args.length)
        {
            // create listener using default queue
            try
            {
                new TibrvListener(Tibrv.defaultQueue(),
                            this,transport,args[i],null);
                System.err.println("Listening on: "+args[i]);
            }
            catch (TibrvException e)
            {
                System.err.println("Failed to create listener:");
                e.printStackTrace();
                System.exit(0);
            }
            i++;
        }

        // dispatch Tibrv events
        while(true)
        {
            try
            {
                Tibrv.defaultQueue().dispatch();
            }
            catch(TibrvException e)
            {
                System.err.println("Exception dispatching default queue:");
                e.printStackTrace();
                System.exit(0);
            }
            catch(InterruptedException ie)
            {
                System.exit(0);
            }
        }
    }

    public void onMsg(TibrvListener listener, TibrvMsg msg)
    {
        System.out.println((new Date()).toString()+  ": subject="+msg.getSendSubject() +
                           ", reply="+msg.getReplySubject()+ ", message="+msg.toString());
        System.out.flush();
    }

    // print usage information and quit
    void usage()
    {
        System.err.println("Usage: java testSdListen ");
        System.err.println("            -user <user> -password <password> <subject-list>");
        System.exit(-1);
    }

    int get_InitParams(String[] args)
    {
        int i=0;
        while(i < args.length-1 && args[i].startsWith("-"))
        {
            if (args[i].equals("-user"))
            {
                username = args[i+1];
                i += 2;
            }
            else
            if (args[i].equals("-password"))
            {
                password = args[i+1];
                i += 2;
            }
            else
                usage();
        }
        return i;
    }

    public static void main(String args[])
    {
        new SdListen(args);
    }
}

