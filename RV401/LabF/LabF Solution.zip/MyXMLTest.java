// TIBCO Rendezvous API Java Development
// File: MyXMLTest.java
// TIBCO Education Services
// Copyright 2005 - TIBCO Software Inc.
// ALL RIGHTS RESERVED

import com.tibco.tibrv.*;

public class MyXMLTest implements TibrvMsgCallback{

    TibrvRvdTransport conn ;
    /** Creates new MyXMLTest */
    public MyXMLTest() throws TibrvException {
        Tibrv.open();
        conn = new TibrvRvdTransport();
        new TibrvListener(Tibrv.defaultQueue(),this, conn,"USERXX.TEST",null);

        TibrvMsg msg = new TibrvMsg();
        msg.setSendSubject("USERXX.TEST");
        msg.add("Name","John");

        String s = "<XML> This is a test </XML>";
        byte[] array = s.getBytes();
        TibrvXml myxml = new TibrvXml(array);
        msg.add("XMLValue",myxml);
        conn.send(msg);
        System.out.println("Message sent");

         for (;;)
         try {
            Tibrv.defaultQueue().dispatch();
         }
         catch(InterruptedException ix) {
             conn.destroy();
             Tibrv.close();
         }

    }
    public void onMsg(TibrvListener l, TibrvMsg msg) {
        try {
			 TibrvMsgField field = msg.getField("XMLValue");

             System.out.println("Recieved subject: " + msg.getSendSubject());
             String a = (String)msg.get("Name");
             System.out.println("Name : " + a );
             if (field != null) {
			 	TibrvXml xml = (TibrvXml) field.data;
			    String s = new String(xml.getBytes());
			    System.out.println("XML Message recieved:" + s);
			 }

        }
        catch (TibrvException ee) {}
    }

    public static void main(String[] args) throws TibrvException {
        MyXMLTest test = new MyXMLTest();
    }
}
