// TIBCO Rendezvous API Java Development
// File: MyVC.java
// TIBCO Education Services
// Copyright 2005 - TIBCO Software Inc.
// ALL RIGHTS RESERVED

import com.tibco.tibrv.*;

public class MyVC implements TibrvMsgCallback{

    TibrvRvdTransport conn ;

	TibrvVcTransport vconn ;
    String kk;
    int i = 0;

    public MyVC() throws TibrvException {
        Tibrv.open();
        conn = new TibrvRvdTransport();
        // Step 1: Create a virtual circuit accept object.
        // Using TibrvVcTransport.createAcceptVc() method
        // you may named it vconn
        vconn = TibrvVcTransport.createAcceptVc(conn);
        System.out.println("Creating an Accept VC Object");

        kk = vconn.getConnectSubject();
        System.out.println("Connect Subject is :" + kk );

	    new TibrvListener(Tibrv.defaultQueue(),this, conn,"USERXX.TEST",null);

	    new TibrvListener(Tibrv.defaultQueue(),this, conn,"_RV.INFO.SYSTEM.VC.*",null);

        TibrvMsg msg = new TibrvMsg();
        msg.setSendSubject("USERXX.TEST");
        msg.setReplySubject(vconn.getConnectSubject());
        msg.add("Data","Let's setup a virtual circuit !");
        conn.send(msg);

        System.out.println("Message sent");

         for (;;)
         try {
            Tibrv.defaultQueue().dispatch();
         }
         catch(InterruptedException ix) {
             conn.destroy();
             Tibrv.close();
         }

    }
    public void onMsg(TibrvListener l, TibrvMsg msg) {
        try {
		  i = i+1;
              String a = (String)msg.get("Data");
              System.out.println("Data : " + a );
              if (i==1)
              {
			   System.out.println("Recieved subject: " + msg.getSendSubject());
			   System.out.println("Reply subject: " + msg.getReplySubject());
               new TibrvListener(Tibrv.defaultQueue(),this, vconn,"TEST2",null);
               System.out.println("Listening on TEST2");
		      }
        }
        catch (TibrvException ee) {}
    }

    public static void main(String[] args) throws TibrvException {
        MyVC vc = new MyVC();
    }
}
